THE DAY BUSINESS RDC – VERSION WEB INSTALLABLE

Cette version est une PWA. Elle est conçue pour être publiée sur un hébergement web puis ajoutée à l'écran d'accueil d'un téléphone comme une application.

Elle ne nécessite pas Flutter ni Android Studio.

Coordonnées :
WhatsApp +243 996 822 203
Vodacom +243 829 325 793
Orange +243 850 765 454
immotheday@gmail.com
